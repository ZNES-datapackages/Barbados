from datapackage_utilities import building, processing


building.infer_metadata(package_name='100-BB-2050')
